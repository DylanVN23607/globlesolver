document.getElementById("getAnswerButton").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (tab.url.includes("globle-game.com")) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        try {
          const practiceData = JSON.parse(localStorage.practice);
          const answer = practiceData.properties.ADMIN.toString();
          return answer;
        } catch (error) {
          return "Unable to retrieve answer.";
        }
      },
    }).then(([result]) => {
      const answerBox = document.getElementById("answerBox");
      answerBox.value = result.result;
    }).catch(() => {
      alert("Error: Unable to retrieve the answer. Make sure you're on a Globle practice page.");
    });
  } else {
    alert("This extension works only on globle-game.com pages.");
  }
});
