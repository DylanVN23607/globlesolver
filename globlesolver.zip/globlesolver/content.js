function updateTitle(title) {
    document.head.querySelectorAll("title").forEach((element) => {
        element.innerHTML = title;
    });
}

let lastHref = window.location.href;

function checkPageAndUpdate() {
    const isPracticePage = window.location.pathname.includes('practice');
    const isGamePage = window.location.pathname.includes('game');

    if (isPracticePage) {
        try {
            if (window.location.href !== lastHref) {
                lastHref = window.location.href;
                return; // Skip updating if the URL has changed
            }
            const practiceData = JSON.parse(localStorage.practice);
            const answer = practiceData.properties.FORMAL_EN.toString();
            updateTitle(answer);
        } catch (error) {
            console.error("Error updating answer:", error);
        }
    }

    if (isGamePage) {
        let countryList;
        let decrypt;

        if (window.location.href !== lastHref) {
            lastHref = window.location.href;
            return; // Skip updating if the URL has changed
        }

        fetch("https://raw.githubusercontent.com/DylanVN23607/globlesolver/refs/heads/main/countrylist.json")
            .then(response => response.json())
            .then(data => {
                countryList = data;
            });

        fetch("https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js")
            .then(() => {
                decrypt = (encryptedText, key) =>
                    CryptoJS.AES.decrypt(encryptedText, key).toString(CryptoJS.enc.Utf8);
            })
            .then(() => {
                fetch(`https://cors-test.landyvilla3-99d.workers.dev/`)
                    .then(response => response.json())
                    .then(data => {
                        let countrySalt = data.answer;
                        let index = decrypt(countrySalt, "ee53e68c3074206a002bf01333b047d5");
                        let adminCountry = countryList[index]["properties"]["ADMIN"];
                        
                        updateTitle(adminCountry);
                    });
            });
    }
}

function main() {
    checkPageAndUpdate()
    setTimeout(main,100)
}
main()