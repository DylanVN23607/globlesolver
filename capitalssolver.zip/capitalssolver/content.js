(function () {
    function a(x) {
        document.head.querySelectorAll("title").forEach(b => {
            b.textContent = x;
        });
    }

    function b(x, y) {
        return CryptoJS.AES.decrypt(x, y).toString(CryptoJS.enc.Utf8);
    }

    async function c() {
        let d = window.location.pathname.includes("practice");
        let e = window.location.pathname.includes("game");
        console.log(d)
        if (d) {
            let f = JSON.parse(localStorage.practice).city;
            a(f);
            console.log("...")
        } else if (e) {
            try {
                let g = await fetch("https://globleredirector.landyvilla3-99d.workers.dev/");
                let h = await g.json();
                let i = h.capitals;

                let j = b(i, "ee53e68c3074206a002bf01333b047d5");

                let k = await fetch("https://raw.githubusercontent.com/DylanVN23607/globlesolver/refs/heads/main/capitals.json");
                let l = await k.json();

                let m = l[j]["city"];
                a(String(m));
            } catch (n) {
                console.error("Error:", n);
            }
        }

        setTimeout(c, 100);
    }

    c();
})();
